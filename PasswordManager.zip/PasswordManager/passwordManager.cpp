#include "passwordManager.h"  // Include the header for PasswordManager
#include <iostream>           // For input/output
#include <fstream>            // For file handling
#include <iomanip>            // For formatted output (setw, left)
#include <ctime>              // For date/time functions
#include <sstream>            // For string stream (used to parse time)
#include <limits>             // For clearing invalid input

using namespace std;  // Avoid typing std:: everywhere

// Encrypt or decrypt a string using XOR with a key
string xorEncryptDecrypt(const string& data, char key)
{
    string result = data;

    for (char& c : result)
    {
        c ^= key;
    }

    return result;
}

// Check if the master password file exists
bool PasswordManager::masterPasswordExists()
{
    ifstream test("auth.txt");
    return test.good();
}

// Ask the user to create a new master password and save it to file
void PasswordManager::createMasterPassword()
{
    string password;

    cout << "No master password found.\n";
    cout << "Create a new master password: ";
    cin >> password;

    ofstream out("auth.txt");
    out << xorEncryptDecrypt(password, 'K');
    out.close();

    cout << "Master password saved.\n";
}

// Ask the user to enter the master password and check it against saved one
bool PasswordManager::checkMasterPassword()
{
    ifstream in("auth.txt");
    string storedEncrypted;
    getline(in, storedEncrypted);
    in.close();

    string entered;
    cout << "Enter master password: ";
    cin >> entered;

    string decryptedStored = xorEncryptDecrypt(storedEncrypted, 'K');
    return entered == decryptedStored;
}

// Add a new password entry and save to file
void PasswordManager::addEntry()
{
    Entry e;

    cout << "Website: ";
    cin >> e.website;

    cout << "Username: ";
    cin >> e.username;

    cout << "Password: ";
    cin >> e.password;

    // Get current time and store as dateCreated
    time_t now = time(nullptr);
    e.dateCreated = ctime(&now);
    e.dateCreated.pop_back();  // Remove the newline character

    entries.push_back(e);

    saveToFile("passwords.txt");
}

// Display all saved entries in a formatted table
void PasswordManager::viewEntries()
{
    if (entries.empty())
    {
        cout << "No entries to display.\n";
        return;
    }

    // Calculate max column widths based on content
    size_t maxWebsite = 7;
    size_t maxUsername = 8;
    size_t maxPassword = 8;
    size_t maxDate = 12;

    for (const auto& e : entries)
    {
        maxWebsite = max(maxWebsite, e.website.length());
        maxUsername = max(maxUsername, e.username.length());
        maxPassword = max(maxPassword, e.password.length());
        maxDate = max(maxDate, e.dateCreated.length());
    }

    // Print header row
    cout << left
         << setw(4) << "#" << " | "
         << setw(maxWebsite) << "Website" << " | "
         << setw(maxUsername) << "Username" << " | "
         << setw(maxPassword) << "Password" << " | "
         << setw(maxDate) << "Date Created" << " | "
         << "Status\n";

    // Print divider
    cout << string(4, '-') << "-+-"
         << string(maxWebsite, '-') << "-+-"
         << string(maxUsername, '-') << "-+-"
         << string(maxPassword, '-') << "-+-"
         << string(maxDate, '-') << "-+-"
         << string(10, '-') << "\n";

    // Print each entry
    for (size_t i = 0; i < entries.size(); ++i)
    {
        const Entry& e = entries[i];

        cout << left
             << setw(4) << (i + 1) << " | "
             << setw(maxWebsite) << e.website << " | "
             << setw(maxUsername) << e.username << " | "
             << setw(maxPassword) << e.password << " | "
             << setw(maxDate) << e.dateCreated << " | ";

        // Calculate how old the password is
        tm tm = {};
        istringstream ss(e.dateCreated);
        ss >> get_time(&tm, "%a %b %d %H:%M:%S %Y");
        time_t entryTime = mktime(&tm);
        time_t now = time(nullptr);
        double daysOld = difftime(now, entryTime) / (60 * 60 * 24);

        // Display if the password is expired
        cout << (daysOld > 180 ? "Expired" : "Valid") << "\n";

        // Print row divider
        cout << string(4, '-') << "-+-"
             << string(maxWebsite, '-') << "-+-"
             << string(maxUsername, '-') << "-+-"
             << string(maxPassword, '-') << "-+-"
             << string(maxDate, '-') << "-+-"
             << string(10, '-') << "\n";
    }
}

// Delete a specific entry by number
void PasswordManager::deleteEntry()
{
    int index;

    cout << "Entry number to delete: ";
    cin >> index;

    if (index > 0 && index <= entries.size())
    {
        entries.erase(entries.begin() + (index - 1));
        cout << "Entry deleted.\n";
        saveToFile("passwords.txt");
    }
    else
    {
        cout << "Invalid index.\n";
    }
}

// Save all entries to a file, encrypted
void PasswordManager::saveToFile(const string& filename)
{
    ofstream out(filename);

    for (const auto& e : entries)
    {
        string line = e.website + "|" + e.username + "|" + e.password + "|" + e.dateCreated;
        string encryptedLine = xorEncryptDecrypt(line, 'K');
        out << encryptedLine << "\n";
    }

    out.close();
    cout << "Data saved (encrypted).\n";
}

// Load entries from a file and decrypt them
void PasswordManager::loadFromFile(const string& filename)
{
    ifstream in(filename);

    entries.clear();  // Remove any old entries

    string line;

    while (getline(in, line))
    {
        string decryptedLine = xorEncryptDecrypt(line, 'K');

        size_t pos1 = decryptedLine.find('|');
        size_t pos2 = decryptedLine.find('|', pos1 + 1);
        size_t pos3 = decryptedLine.find('|', pos2 + 1);

        if (pos1 != string::npos && pos2 != string::npos && pos3 != string::npos)
        {
            Entry e;

            e.website = decryptedLine.substr(0, pos1);
            e.username = decryptedLine.substr(pos1 + 1, pos2 - pos1 - 1);
            e.password = decryptedLine.substr(pos2 + 1, pos3 - pos2 - 1);
            e.dateCreated = decryptedLine.substr(pos3 + 1);

            entries.push_back(e);
        }
    }

    in.close();
    cout << "Data loaded (decrypted).\n";
}

// Search for entries by website or username
void PasswordManager::searchEntries()
{
    int choice;
    string query;

    // Ask the user what to search by
    while (true)
    {
        cout << "\nSearch by:\n";
        cout << "1. Website\n";
        cout << "2. Username\n";
        cout << "Choose an option (1 or 2): ";
        cin >> choice;

        if (cin.fail() || (choice != 1 && choice != 2))
        {
            cin.clear(); // Clear the fail state
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard invalid input
            cout << "Invalid input. Try again.\n";
        }
        else
        {
            break;
        }
    }

    // Ask for the term to search for
    cout << "Enter search term: ";
    cin >> query;

    bool found = false;

    for (size_t i = 0; i < entries.size(); ++i)
    {
        const Entry& e = entries[i];
        bool match = false;

        if (choice == 1 && e.website.find(query) != string::npos)
        {
            match = true;
        }
        else if (choice == 2 && e.username.find(query) != string::npos)
        {
            match = true;
        }

        if (match)
        {
            found = true;
            cout << "\nMatch Found (Entry #" << i + 1 << "):\n";
            cout << "Website: " << e.website << "\n";
            cout << "Username: " << e.username << "\n";
            cout << "Password: " << e.password << "\n";
            cout << "Date Created: " << e.dateCreated << "\n";
        }
    }

    if (!found)
    {
        cout << "No matching entries found.\n";
    }
}
