// Header guard to prevent this file from being included more than once
#ifndef PASSWORD_MANAGER_H
#define PASSWORD_MANAGER_H

// Include string and vector for storing text and lists
#include <string>
#include <vector>

using namespace std;  // Avoid using std:: everywhere

// This struct represents a single password entry
struct Entry
{
    // The website this login is for
    string website;

    // The username for the account
    string username;

    // The password for the account
    string password;

    // The date the entry was created
    string dateCreated;
};

// The PasswordManager class handles all core features
class PasswordManager
{
private:

    // A list of all password entries
    vector<Entry> entries;

public:

    // Add a new password entry
    void addEntry();

    // View all saved entries
    void viewEntries();

    // Delete a specific entry by its number
    void deleteEntry();

    // Save entries to a file
    void saveToFile(const string& filename);

    // Load entries from a file
    void loadFromFile(const string& filename);

    // Search entries by website or username
    void searchEntries();

    // Check if a master password has been created
    bool masterPasswordExists();

    // Ask the user to enter and verify the master password
    bool checkMasterPassword();

    // Let the user create a new master password
    void createMasterPassword();
};

#endif
