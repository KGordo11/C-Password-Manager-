#include <iostream>           // Allows input and output (cin, cout)
#include "passwordManager.h"  // Includes the PasswordManager class

using namespace std;  // So we don't have to write std:: in front of cout and cin

int main()
{
    // Create a PasswordManager object to manage passwords
    PasswordManager manager;

    // Check if a master password file exists
    if (!manager.masterPasswordExists())
    {
        // If it doesn't exist, ask the user to create one
        manager.createMasterPassword();
    }
    else
    {
        // If a master password exists, ask the user to log in
        int attempts = 0;

        // Keep prompting until the user enters the correct password or resets it
        while (true)
        {
            // Check if the entered password matches
            if (manager.checkMasterPassword())
            {
                // Password is correct, break out of the loop
                break;
            }

            // Tell the user the password was incorrect
            cout << "Incorrect master password.\n";

            // Give the user options after a failed login
            cout << "1. Try again\n";
            cout << "2. Reset master password (existing data will remain accessible)\n";
            cout << "Choose an option: ";

            int choice;
            cin >> choice;

            // If the user wants to try again, loop continues
            if (choice == 1)
            {
                continue;
            }

            // If the user wants to reset the master password
            else if (choice == 2)
            {
                // Allow the user to create a new master password
                manager.createMasterPassword();
                break;
            }

            // If the user enters anything else, exit the program
            else
            {
                cout << "Invalid option. Exiting.\n";
                return 1;
            }
        }
    }

    // Load saved password entries from file (if any)
    manager.loadFromFile("passwords.txt");

    // This variable stores the user's menu selection
    int choice;

    // Main menu loop — runs until the user chooses to exit
    do
    {
        // Display the main menu options
        cout << "\n--- Password Manager ---\n";
        cout << "1. Add Entry\n";
        cout << "2. View Entries\n";
        cout << "3. Delete Entry\n";
        cout << "4. Search Entries\n";
        cout << "0. Exit\n";
        cout << "Choose an option: ";
        cin >> choice;

        // Perform the action the user selected
        switch (choice)
        {
            case 1:
                // Add a new password entry
                manager.addEntry();
                break;

            case 2:
                // Display all saved entries
                manager.viewEntries();
                break;

            case 3:
                // Delete an entry by its number
                manager.deleteEntry();
                break;

            case 4:
                // Search for entries by website or username
                manager.searchEntries();
                break;

            case 0:
                // Exit the program with a goodbye message
                cout << "\nSaving and exiting... Goodbye!\n";
                break;

            default:
                // Handle invalid menu selections
                cout << "Invalid option. Try again.\n";
                break;
        }
    } 
    // Keep looping until user selects "Exit"
    while (choice != 0); 

    return 0;
}
